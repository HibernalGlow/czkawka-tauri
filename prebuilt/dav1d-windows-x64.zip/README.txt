﻿dav1d Prebuilt Package for Windows x64
========================================
Build Date: 2025-10-02 00:17:30
Source: vcpkg
Platform: x64-windows

Files included:
- bin/dav1d.dll
- lib/dav1d.lib
- lib/pkgconfig/dav1d.pc
- include/dav1d/*
- tools/pkgconf/*

Usage in CI:
1. Extract this archive to C:\dav1d
2. Set PKG_CONFIG_PATH=C:\dav1d\lib\pkgconfig
3. Add C:\dav1d\bin and C:\dav1d\tools\pkgconf to PATH
